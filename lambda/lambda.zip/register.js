const AWS = require('aws-sdk');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');


const ddb = new AWS.DynamoDB.DocumentClient();
const USERS_TABLE = process.env.USERS_TABLE; // set in Lambda env


exports.handler = async (event) => {
try {
const body = JSON.parse(event.body || '{}');
const { email, password } = body;
if (!email || !password || password.length < 8) {
return { statusCode: 400, body: JSON.stringify({ message: 'Invalid input' }) };
}


// Check if user exists
const existing = await ddb.get({ TableName: USERS_TABLE, Key: { email } }).promise();
if (existing.Item) {
return { statusCode: 409, body: JSON.stringify({ message: 'User already exists' }) };
}


// Hash password
const salt = bcrypt.genSaltSync(10);
const passwordHash = bcrypt.hashSync(password, salt);


const item = {
email,
userId: uuidv4(),
passwordHash,
createdAt: new Date().toISOString(),
};


await ddb.put({ TableName: USERS_TABLE, Item: item }).promise();


return { statusCode: 201, body: JSON.stringify({ message: 'User created' }) };
} catch (err) {
console.error(err);
return { statusCode: 500, body: JSON.stringify({ message: 'Server error' }) };
}
};