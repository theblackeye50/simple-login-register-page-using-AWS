const AWS = require('aws-sdk');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');


const ddb = new AWS.DynamoDB.DocumentClient();
const USERS_TABLE = process.env.USERS_TABLE;
const JWT_SECRET = process.env.JWT_SECRET; // store securely in Parameter Store or Secrets Manager


exports.handler = async (event) => {
try {
const body = JSON.parse(event.body || '{}');
const { email, password } = body;
if (!email || !password) {
return { statusCode: 400, body: JSON.stringify({ message: 'Invalid input' }) };
}


const res = await ddb.get({ TableName: USERS_TABLE, Key: { email } }).promise();
const user = res.Item;
if (!user) {
return { statusCode: 401, body: JSON.stringify({ message: 'Invalid credentials' }) };
}


const ok = bcrypt.compareSync(password, user.passwordHash);
if (!ok) {
return { statusCode: 401, body: JSON.stringify({ message: 'Invalid credentials' }) };
}


// Issue JWT
const token = jwt.sign({ sub: user.userId, email: user.email }, JWT_SECRET, { expiresIn: '1h' });


return { statusCode: 200, body: JSON.stringify({ message: 'Login successful', token }) };
} catch (err) {
console.error(err);
return { statusCode: 500, body: JSON.stringify({ message: 'Server error' }) };
}
};